Hay un .env de ejemplo en este zip, después de configurar .env con su información, colocar en la raíz del backend para su funcionamiento.

Elegir la carpeta raíz del backend para los siguientes dos pasos:

en Libraries.txt, se encuentra el commando de instalación para las librerías de node_modules

luego de hacer estos dos pasos para iniciar el backend utilizer: npm run start:dev

Todas las consultas se encuentran en la carpeta presentation, acá se encuentran los controladores con el Sistema de Rest API que utiliza (post,put,get,etc.) con la url que pide.

Algunas queries requieren un header para elegir la base de datos (db: mongo, cassandra o dynamo), también como un body.


Las queries get requieren de los parametros pedidos en cada uno como parte de la url