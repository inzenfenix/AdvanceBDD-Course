Después de configurar .env con su información, colocar en la raíz del backend para su funcionamiento.

Elegir la carpeta raíz del backend para los siguientes dos pasos:

en Libraries.txt, se encuentra el commando de instalación para las librerías de node_modules

luego de hacer estos dos pasos para iniciar el backend utilizer: npm run start:dev